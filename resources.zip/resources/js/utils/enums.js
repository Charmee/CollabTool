export const PricingType = {
  HOURLY: 'hourly',
  FIXED: 'fixed',
};
