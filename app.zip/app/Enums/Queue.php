<?php

namespace App\Enums;

enum Queue: string
{
    case EMAIL = 'email';
}
